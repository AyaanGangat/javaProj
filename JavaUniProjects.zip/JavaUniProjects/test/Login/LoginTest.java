/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Login;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author yussu
 */
public class LoginTest {
    
   
    public LoginTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class Login.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Login.main(args);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of CheckUserName method, of class Login.
     */
    @Test
    public void testCheckUserName() {
        System.out.println("CheckUserName");
        String UserName = "Yus_";
        boolean expResult = true;
        boolean result = Login.CheckUserName(UserName);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of PasswordComplexity method, of class Login.
     */
    @Test
    public void testPasswordComplexity() {
        System.out.println("PasswordComplexity");
        String password = "Yus_55211";
        boolean expResult = true;
        boolean result = Login.PasswordComplexity(password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of registerUser method, of class Login.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        String user = "Yus_";
        String pas = "Yus_55211";
        String expResult = "The two conditions have been met and the user has been successfully registered";
        String result = Login.registerUser(user, pas);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of loginUser method, of class Login.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        String userLogin = "Yus_";
        String pasLogin = "Yus_55211";
        String capUser = "Yus_";
        String capPas = "Yus_55211";
        boolean expResult = true;
        boolean result = Login.loginUser(userLogin,capUser, pasLogin, capPas);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of returnLoginStatus method, of class Login.
     */
    @Test
    public void testReturnLoginStatus() {
        System.out.println("returnLoginStatus");
        boolean check = true;
        String expResult = "A successful login";
        String result = Login.returnLoginStatus(check);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }
    
}
