/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package Login;

import java.util.Scanner;

/**
 *
 * @author yussu
 */
public class Login {

    private static String capUser, capPas;

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String user = "";
        String pas = "";
        String name;
        String surname;
        boolean userNameCheck = false;
        boolean pasCheck = false;
        boolean check;

        System.out.println("Please enter your Name");
        name = input.next();

        System.out.println("Please enter your Surname");
        surname = input.next();

        while (!userNameCheck) {    //This loops the username till the user meets the username requirements

            System.out.println("Please enter a Username: ");
            user = input.next();

            System.out.println(CheckUserName(user));
            userNameCheck = CheckUserName(user);

            if (userNameCheck) {

                System.out.println("Username successfully captured");
            } else {
                System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length");
            }

        }

        while (!pasCheck) { //This loops the password till the user meets the password complexity requirements

            System.out.println("Please enter a Password: ");
            pas = input.next();

            System.out.println(PasswordComplexity(pas));
            pasCheck = PasswordComplexity(pas);

            if (pasCheck) {
                System.out.println("Password successfully captured");
            } else {
                System.out.println("Password is not correctly formated, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.\n ");

            }
        }

        System.out.println(registerUser(user, pas));

        capUser = user;
        capPas = pas;

        System.out.println("Please enter your Username to login");
        user = input.next();

        System.out.println("Please enter your Password to login");
        pas = input.next();

        check = loginUser(user, capUser, pas, capPas);
        System.out.println(check);
        while (!check) { //This loops to check if the login username and password is incorrect
            System.out.println("Username or password is incorrect, please try again");

            System.out.println("Please enter your Username to login");
            user = input.next();

            System.out.println("Please enter your Password to login");
            pas = input.next();

            check = loginUser(user, capUser, pas, capPas);
            System.out.println(check);
        }
        System.out.println(returnLoginStatus(check));

        System.out.println("Welcome " + name + " " + surname + " it is great to see you again\n");
    }

    public static boolean CheckUserName(String UserName) { // This method checks if the username meets the requirements

        boolean UnderScore;
        boolean NameLength;
        UnderScore = UserName.contains("_");
        NameLength = UserName.length() <= 5;

        return NameLength && UnderScore;

    }

    public static boolean PasswordComplexity(String password) { // This method checks if the password meets the requirements

        boolean num = false;
        boolean capLetter = false;
        boolean specialChar = false;

        for (int i = 0; i < password.length(); i++) {

            char c = password.charAt(i);

            if (c >= 65 && c <= 90) {
                capLetter = true;
            }

            if ((c >= 33 && c <= 47) || (c >= 58 && c <= 64) || (c >= 91 && c <= 96)
                    || (c >= 123 && c <= 126)) {
                specialChar = true;
            }

            if (c >= 48 && c <= 57) {
                num = true;
            }

        }

        return ((password.length() >= 8 && capLetter && specialChar && num));
    }

    public static String registerUser(String user, String pas) { //This method returns a prompt to the user if the username and password requirements are met

        String out = "";

        if (!CheckUserName(user)) {

            out += "Username is incorrectly formatted";

        }

        if (!PasswordComplexity(pas)) {

            out += "Password does not meet the complexity requirements ";
        }

        if (out.isEmpty()) {
            out += "The two conditions have been met and the user has been successfully registered";
        }

        return out;

    }

    public static boolean loginUser(String userLogin, String capUser, String pasLogin, String capPas) { // This method stores the users login information

        if (capUser.equals(userLogin)) {

            if (capPas.equals(pasLogin)) {
                return true;
            }

        }
        return false;
    }

    public static String returnLoginStatus(boolean check) { //This method tells the user if the login is succesful or if its not

        if (check) {
            return "A successful login";

        }
        return "A failed login";
    }

}
